
#include "list.h"

bool listIsPalindromic(List l) {
	// TODO
	return false;
}

