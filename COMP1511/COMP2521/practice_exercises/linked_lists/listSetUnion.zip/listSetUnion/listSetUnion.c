
#include "list.h"

List listSetUnion(List s1, List s2) {
	// TODO
	return newList();
}

