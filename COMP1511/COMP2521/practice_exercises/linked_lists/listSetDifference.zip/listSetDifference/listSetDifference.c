
#include "list.h"

List listSetDifference(List l1, List l2) {
	// TODO
	return NULL;
}

