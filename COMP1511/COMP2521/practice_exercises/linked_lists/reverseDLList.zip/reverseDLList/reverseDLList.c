
#include "list.h"

void reverseDLList(List l) {
	// TODO
}

