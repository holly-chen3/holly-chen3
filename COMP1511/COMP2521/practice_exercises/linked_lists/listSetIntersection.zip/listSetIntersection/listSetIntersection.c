
#include "list.h"

List listSetIntersection(List s1, List s2) {
	// TODO
	return newList();
}

