package example.grade;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class GradeScreen {

    private Stage stage;
    private String title;
    private GradeController controller;
    private Scene scene;


    public GradeScreen(Stage stage) throws IOException {
        this.stage = stage;
        title = "Grade Screen";

        controller = new GradeController();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("grade2.fxml"));
        
        /**
         * Later try the following to load "grade2.fxml", 
         * for 'live' (on key-release) update of grade.
         * FXMLLoader loader = new FXMLLoader(getClass().getResource("grade2.fxml"));

         */
        
        loader.setController(controller);

        // load into a Parent node called root
        Parent root = loader.load();
        scene = new Scene(root, 800, 600);
    }

    public void start() {
        stage.setTitle(title);
        stage.setScene(scene);
        stage.show();
    }
		
}
