

package example.animation;

import javafx.animation.*;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class Example1 extends Application {

	@Override
	public void start(Stage stage) {
		
		stage.setTitle("Example 1 ");
		Group grp = new Group();
		final Scene scene = new Scene(grp, 600, 450);
		scene.setFill(Color.WHITE);

		final Rectangle rect = new Rectangle(100, 50, 100, 50);
		rect.setFill(Color.BROWN);

		final Label lbl = new Label();
		lbl.setText(Integer.toString(1));
		lbl.setTranslateX(50);
		lbl.setTranslateY(50);
		
		grp.getChildren().addAll(rect, lbl);
		stage.setScene(scene);
		stage.show();

		EventHandler<ActionEvent> eh = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				rect.setFill(Color.BLUE);
				if(rect.getArcHeight() == 0) {
					rect.setArcHeight(40); rect.setArcWidth(40);
				}
				else {
					rect.setArcHeight(0); rect.setArcWidth(0);					
				}
				
				int currentValue = Integer.parseInt(lbl.getText()); 
				lbl.setText(Integer.toString(currentValue + 1));
				
			}
		};

		final Timeline timeline = new Timeline();
		timeline.setCycleCount(Timeline.INDEFINITE);
		timeline.setAutoReverse(true);
		

		final KeyValue kv1 = new KeyValue(rect.xProperty(), 300, Interpolator.LINEAR);
		final KeyValue kv2 = new KeyValue(rect.yProperty(), 300, Interpolator.LINEAR);

		final KeyFrame kf1 = new KeyFrame(Duration.millis(1400), kv1);
		final KeyFrame kf2 = new KeyFrame(Duration.millis(1400), kv2);

		final KeyFrame kf3 = new KeyFrame(Duration.millis(1400), eh);

		timeline.getKeyFrames().addAll(kf1, kf2, kf3);

		timeline.play();

	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
